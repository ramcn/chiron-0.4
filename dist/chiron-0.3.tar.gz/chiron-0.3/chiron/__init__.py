# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
"""Initial file for the package"""
